/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.upc.etsetb.poo.laboratorio.sesion5.main;

import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author adam.el.bouchaibi
 */
public class Impresora {
    private String nombre;
    private LinkedList<Trabajo> cola;
    
    
    public Impresora(String nombre){
        this.nombre=nombre;
        this.cola = new LinkedList<>();
    }
    
    public void addTrabajoEnCola(Trabajo trabajo){
        this.cola.add(trabajo);
    }
    
    public boolean procesaSiguienteTrabajo(){
        if(this.cola.size()==0) return false;
        this.cola.remove();
        return true;
    }
    
    public boolean priorizaTrabajoEnCola(int id){
        Iterator<Trabajo> it = cola.iterator();
        Trabajo t;
        while(it.hasNext()){
            t=it.next();
            if(t.getId()== id){
                this.cola.remove(t);
                this.cola.add(0,t);
                return true;
                
            }
        }
        return false;
        }
    }

