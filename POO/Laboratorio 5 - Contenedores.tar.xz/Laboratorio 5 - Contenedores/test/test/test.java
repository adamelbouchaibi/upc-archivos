/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

import edu.upc.etsetb.poo.laboratorio.sesion5.main.Trabajo;

/**
 *
 * @author adam.el.bouchaibi
 */
public class test {
    
    public static void main (String[] args){
        Trabajo trabajo = new Trabajo(1,"AD","PDF");
        System.out.println(trabajo.toString());
    }
}
