/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.upc.etsetb.poo.ordenacion.aleatorio;

import java.util.Random;

/**
 *
 * @author adam.el.bouchaibi
 */
public class OrdenaInsercion {
    public static void main (String args[]){
        
        Random random = new Random();
        
        int[] arrayEnteros= new int[random.nextInt(10)+1];
        
        for(int i=0;i<arrayEnteros.length;i++){
            arrayEnteros[i]=random.nextInt(40);
        }
        
        
        System.out.print("El array sin ordenar es: \n[ ");
        for (int i=0; i<arrayEnteros.length;i++){
            
            System.out.print(arrayEnteros[i]+ " ");
        }
        System.out.print("]");
        
        for(int i=1;i<arrayEnteros.length;i++){
            
            int ref=arrayEnteros[i];
            int j =i-1;
            
            while(j>=0 && arrayEnteros[j]>ref){
                
                arrayEnteros[j+1]=arrayEnteros[j];
                
                j=j-1;   
            }
            
            arrayEnteros[j+1]=ref;
        
        }
        
        
        System.out.print("\nEl array ordenado es \n[ ");
        
        for (int i=0; i<arrayEnteros.length;i++){
            
            System.out.print(arrayEnteros[i]+ " ");
        }
        System.out.print("]");
    }
}
